<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PermissionResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'codename' => $this->name,
            'display_name' => $this->display_name,
            'description' => $this->description,
            'group' => $this->group,
            'guard_name' => $this->guard_name,
            'created_at' => $this->created_at?->toISOString(),
        ];
    }
}
